<?php

if( get_theme_mod('active_section_utilities') ) get_template_part( 'template-parts/section-utilities' );
