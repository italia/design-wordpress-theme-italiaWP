<?php
/*
 * ### ERRORE ###
 *
 */
?>

<div class="Prose Alert Alert--error Alert--withIcon u-layout-prose u-padding-r-bottom u-padding-r-right u-margin-r-bottom" role="alert">
    <h2 class="u-text-h3">
        Errore
    </h2>
    <p class="u-text-p">Nessun contenuto presente.</p>
</div>