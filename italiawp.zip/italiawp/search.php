<?php

get_header();

get_template_part( 'template-parts/search-loop' );

get_sidebar();
get_footer();